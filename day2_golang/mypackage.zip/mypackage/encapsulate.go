package mypackage

//public(Addnumber) it can be accessed outside also with go file
func Addnumber(num1 int,num2 int) int{
	return num1 + num2
}